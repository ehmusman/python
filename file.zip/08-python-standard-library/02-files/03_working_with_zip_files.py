from pathlib import Path
from zipfile import ZipFile

# Writing in Zip file

with ZipFile("file.zip", "w") as zip:
    for path in Path("08-python-standard-library").rglob("*.*"):
        zip.write(path)

# Reading from Zip file

with ZipFile("file.zip") as zip:
    print(zip.namelist())